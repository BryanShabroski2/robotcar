struct io_peripherals *import_registers( void );
