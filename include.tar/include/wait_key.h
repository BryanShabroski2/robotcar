/*
 * wait_key.h
 *
 *  Created on: Mar 18, 2017
 *      Author: steveb
 */

#ifndef WAIT_KEY_H_
#define WAIT_KEY_H_

bool wait_key( int timeout_ms, int * pressed_key );

#endif /* WAIT_KEY_H_ */
